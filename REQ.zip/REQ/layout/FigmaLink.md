## Figma Link
https://www.figma.com/file/zlKQQCLBCgFjm7RU2WQZnO/ES-PROJECT?type=design&node-id=0%3A1&mode=design&t=PfRhpS94VJbD4DxD-1