# Test Report - REQ1.2 - Register

## Test Scenery

1. User is on '/login' 
2. System redirects User to '/' page if already logged in

## Actions

3. System shows '/login' page with "Username" and "Password" Register boxes
4. User inputs their credentials on "Username" and "Password" Register boxes
   1. User inputs valid credentials
      1. Username: 'myNewUser5'
      2. Password: 'password'
   2. User inputs short password
      1. Username: 'justAUser1'
      2. Password: 'pa'
   3. User inputs short username
      1. Username: 'my'
      2. Password: 'password'
   4. User inputs invalid characters on username
      1. Username: 'myNewUser1!'
      2. Password: 'password'
   5. User inputs invalid character on password
      1. Username: 'myNewUser1'
      2. Password: 'pass^word'
   6. User inputs long username
      1. Username: 'justAUser11111111111111111111111111111111'
      2. Password: 'password'
   7. User inputs long password
      1. Username: 'myNewUser1'
      2. Password: 'password12345678999999999999999999999999'
   8. Creating a user with the same username as an existing user
      1. Username: 'justAUser1'
      2. Password: 'password'
5. User clicks 'Register' button

## Expected Result

6. If credentials are valid, System redirects User to '/' page and user becomes registered
7. If credentials are invalid, System feedbacks with the reason

## Result Obtained
**OK**

- Problem:
4.4 - This user is accepted, but it shouldn't be accepted because it has an invalid character
4.5 - This password is accepted, but it should be rejected because it has an invalid character
4.7 - Feedback is wrong, it should be 'Password must be between 6 and 18 characters'
      but is 'Password must be between 6 and 20 characters'
- To fix use YUP as a library

- Report: All seems fixed.
- Conclusion: It's OK.