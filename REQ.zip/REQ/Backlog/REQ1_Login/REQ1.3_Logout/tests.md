# Test Report - REQ1.3

## Test Scenery

1. User enters '/login' page (and is logged in)

## Actions

1. User clicks Logout button (turn off symbol)

## Expected Result

1. User successfully logout

## Result Obtained
**OK**