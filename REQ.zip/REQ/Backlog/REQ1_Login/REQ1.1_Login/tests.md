# Test Report - REQ1.1 - Login

## Test Scenery

1. User is registered

## Actions

1. User is on page '/login'
2. User types the username on the username box and the password on the password box
   1. User used valid credentials
      1. Username: 'justAUser1'
      2. Password: 'admin123'
   2. User used invalid credentials
      1. Username: any
      2. Password: any
   3. User used empty credentials
      1. Username: ''
      2. Password: ''
3. User clicks the 'Login' button


## Expected Result

1. System redirects the user to the '/' page if the login was successful else feedback for invalid credentials should appear
2. User is not able to go to any other page if the login was not successful

## Result Obtained
**OK**