# Test Report - REQ4.1

## Test Scenery

1. Reviewer is logged on.
2. Reviewer has at least one question to review.

## Actions

1. Reviewer goes to '/review-question' page.
2. Reviewer clicks 'Accept' button.
3. Reviewer clicks 'Submit' button.
4. System redirects the reviewer to the '/' page and the vote is submited.

## Expected Result

1. On the 3th vote the question changes states to 'accepted'.

## Result Obtained

**OK**
