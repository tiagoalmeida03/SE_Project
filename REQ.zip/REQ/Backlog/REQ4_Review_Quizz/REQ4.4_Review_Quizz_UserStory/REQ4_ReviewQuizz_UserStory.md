# USER STORY - REVIEW QUIZZ

As a Reviewer, I want to be able to review quizzes in order to secure quality of the quizzes.