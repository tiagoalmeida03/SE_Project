# REQ4.3 - Reviewer can see the Quiz to review

- **PRIMARY ACTOR:** Reviewer

- **SCOPE:** User Goals

- **STAKEHOLDER AND INTERESTS:** Creator, Solvers

- **PRECONDITIONS**
1. Reviewer is logged on
2. Reviewer has least one quizz to review

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** Reviewer can see one 'in evaluation' quizz on '/review-quizz' page

- **MAIN SUCESS SCENARIO:**
1. Reviewer enters '/review-quizz' page
2. System shows page with the Question and options (with answer in green)

- **EXTENSIONS/ALTERNATIVE PATHS:**

None

# Guidelines & Restrictions

Page shows votation Status