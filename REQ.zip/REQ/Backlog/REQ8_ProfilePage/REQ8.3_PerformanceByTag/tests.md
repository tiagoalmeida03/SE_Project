# Test Report - REQ8.3

## Test Scenery

1. User is logged on

## Actions

1. User enters '/profile' page 

## Expected Result

1. Chart with approved and unapproved quizzes by tag is displayed

### If solver

1. Chart with approved and unapproved quizzes by tag is displayed as well as chart with correct and incorrect answers by tag

## Result Obtained
**OK**
