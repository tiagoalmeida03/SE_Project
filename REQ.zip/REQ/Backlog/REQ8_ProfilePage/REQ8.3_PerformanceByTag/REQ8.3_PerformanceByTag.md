# REQ8.3 - My profile includes my performance by tag (success&failed) 

- **PRIMARY ACTOR:** User

- **SCOPE:** User Goals

- **STAKEHOLDER AND INTERESTS:** Solvers, Creators

- **PRECONDITIONS:**
1. User is logged on

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** User can see approved and not approved quizzes by tag in '/profile' page 
- **IF SOLVER:** User can also see correct and incorrect answers by tag in '/profile' page

- **MAIN SUCESS SCENARIO:**
1. User enters '/profile' page
2. System shows page with with approved and not approved quizzes by tag

- **EXTENSIONS/ALTERNATIVE PATHS:**
2. System shows page with with approved and not approved quizzes as well as correct and incorrect answers by tag
---

# Guidelines & Restrictions

None
