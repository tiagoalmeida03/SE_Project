# REQ8.2 - User Detailed Profile Page 

- **PRIMARY ACTOR:** User

- **SCOPE:** User Goals

- **STAKEHOLDER AND INTERESTS:** None

- **PRECONDITIONS:**
1. User is logged on

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** User can see detailed information in '/profile' page

- **MAIN SUCESS SCENARIO:**
1. User enters '/profile' page
2. System shows page with Detailed* information

- **EXTENSIONS/ALTERNATIVE PATHS:** None

---

# Guidelines & Restrictions

- Detailed Information:

1. (As creator) Number and racio of Quizzes approved / reproved (DIVIDED BY TAGS)
2. (As solver) Number and racio of correct / incorrect Answers (DIVIDED BY TAGS)