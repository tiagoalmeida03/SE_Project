# Test Report - REQ8.2

## Test Scenery

1. User enters '/profile' page
2. System shows page with Detailed* information

## Actions

1. User logins in at http://localhost:3000/admin
2. On the top bar click on the username of the account
3. See the detailed information in '/profile' page

## Expected Result

1. The user can see the Number and racio of Quizzes approved / reproved (DIVIDED BY TAGS) if the user is a creator.
2. The user can see the Number and racio of correct / incorrect Answers (DIVIDED BY TAGS) if the user is a solver.

## Result Obtained
**OK**

- Problem:
1. The test failed because the only results showing were the Number and racio of Quizzes approved / reproved (DIVIDED BY TAGS).
1. The test failed because the only results showing were the Number and racio of Quizzes approved / reproved (DIVIDED BY TAGS).
2. The Number and racio of correct / incorrect Answers (DIVIDED BY TAGS) were not showing at all. 

- Report: All appear correctly.
- Conclusion: It's OK.
