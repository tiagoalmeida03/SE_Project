# Test Report - REQ2.2

## Test Scenery

1. User is logged in

## Actions

1. User clicks 'Review Quiz' button on NavBar 

## Expected Result

System redirects to '/review-quizz' and 'Review Quiz' button on NavBar changes background to darker blue

## Result Obtained
**OK**
