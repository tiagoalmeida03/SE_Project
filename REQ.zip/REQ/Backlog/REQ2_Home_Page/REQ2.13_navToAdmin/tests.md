# Test Report - REQ2.13

## Test Scenery

1. Users are logged in

## Actions

1. Criei um teste
2. Fiz o teste com dois users diferentes

## Expected Result

1. User should be able to go from any page (except '/login') to '/admin' page

## Result Obtained
**OK**
