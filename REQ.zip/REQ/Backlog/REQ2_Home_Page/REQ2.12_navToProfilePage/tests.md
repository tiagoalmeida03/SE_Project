# Test Report - REQ2.1 -  "Show My Quizzes"

## Test Scenery 
- User be logged on (it was tested while user with username "justAUser2" and the associate password was logged on).

## Actions
-  User can go from any page (except '/login') to '/profile' page:
    - Once logged in was not possible to go to '/login' unless if logged out.
    - Tested going to new pages through QuirkedUpSoftware", "Admin", "Create Question", "Review Question", "Create Test", "Solve Test", 'profile'.

## Expected Result
-  User can go from any page (except '/login') to '/profile' page:
    - Once logged in was not possible to go to '/login' unless if logged out.
    - Tested going to new pages through QuirkedUpSoftware", "Admin", "Create Question", "Review Question", "Create Test", "Solve Test", 'profile'.

## Result Obtained
**OK**

- Problem: System didn't shows page 'Create Quiz' option on Navigation Bar:
- Report: All seems fixed.
- Conclusion: It's OK.
