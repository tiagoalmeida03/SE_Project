# Test Report - REQ 2.3

## Test Scenery

1. User must be logged in

## Actions

1. User enters any page (except '/login')
2. User clicks 'Solve Test' button on the NavBar

## Expected Result

1. User enters the '/choose-test' page
2. 'Solve Test' button on NavBar changes background to darker blue

## Result Obtained
**OK**
