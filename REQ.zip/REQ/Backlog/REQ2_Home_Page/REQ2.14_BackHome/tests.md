# Test Report - REQ2.14 - Navigate to 'Home' Page

## Introduction
This report summarizes the testing performed to verify the navigate home functionality as per Requirement 2.14. The objective was to ensure that when user clicks on Logo is redirected to '/' page.

## Test Procedure
1.User enters any page (except '/login')
2.System shows page with our Logo on Navigation Bar (Img= /DEV/frontend/src/IMAGES/Logo.png)
3.User clicks on Logo
4.System redirects to '/' page

## Test Results
**OK**
