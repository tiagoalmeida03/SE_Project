# TEST REPORT REQ2.9 - Hall Of Fame: Solvers

## Test Scenery
1. User enters '/' page
2. System shows page with 'Hall of Fame - Creators'

## Actions
1. Create a test
2. Solved a test with 2 users

## Expected Result
- The user that scored more in the tests should rank higher in the Hall of Fame

## Result Obtained
**OK**