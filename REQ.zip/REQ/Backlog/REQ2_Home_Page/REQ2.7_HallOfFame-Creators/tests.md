# TEST REPORT REQ2.6 - Show all Creators


## Test Scenery
1. User enters '/' page
2. System shows page with 'Hall of Fame - Creators' -> Creators sorted by score

## Actions
1. User logins in at http://localhost:3000/admin
2. User checks on right side of display the Hall of Fame Board : Creators

## Expected Result
- Show all creator's name 

## Result Obtained
**OK**
