# Test Report - REQ2.5

## Test Scenery
1. Creator is logged on
2. Creator has at least one Draft    

## Actions
User can acess '/' page. Sistem can show user's drafts, user can select drafts, but is redirected to a white page and not the correct page, should be redirected '/create-quizz/{quiz_id}'. This last page, don't work.

## Expected Result
1. User enters '/' page
2. System shows page with User's Drafts
3. User selects one Draft
4. System redirects to '/create-quizz/{quiz_id}' page

## Result Obtained
**OK**

- Problem: User can acess '/' page but can't access '/create-quizz/{quiz_id}' page.
- Report: The user can now enter from '/' page to '/create-quizz/{quiz_id}' page.
- Conclusion: It's OK.