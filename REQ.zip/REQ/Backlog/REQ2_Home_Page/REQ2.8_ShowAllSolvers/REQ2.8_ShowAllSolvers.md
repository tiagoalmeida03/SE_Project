# REQ2.8 - Show All Solvers

- **PRIMARY ACTOR:** User

- **SCOPE:**  User Goals

- **STAKEHOLDER AND INTERESTS:** Solvers

- **PRECONDITIONS:**
1. User is logged on
2. At least one Solver has solved one test

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** User can see All Solvers

- **MAIN SUCESS SCENARIO:**
1. User enters '/' page
2. System shows page with Solvers -> Solvers sorted by score

- **EXTENSIONS/ALTERNATIVE PATHS:** None

---

# Guidelines & Restrictions

- Show solver's name and score
- Score = sum of correct answers in every test
