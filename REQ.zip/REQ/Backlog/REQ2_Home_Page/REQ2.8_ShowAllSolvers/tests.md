# TEST REPORT REQ2.8 - Show All Solvers

## Test Scenery
1. User enters '/' page
2. System shows page with 'Solvers'

## Actions
1. Create a test
2. Solved a test with 3 users

## Expected Result
- The user that scored more in the tests should rank higher in the Hall of Fame - Solvers

## Result Obtained
**OK**