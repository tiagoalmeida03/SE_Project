# REQ2.10 - Show My Quizzes

- **PRIMARY ACTOR:** Creator

- **SCOPE:** User Goals

- **STAKEHOLDER AND INTERESTS:** None

- **PRECONDITIONS:**
1. User is logged on
2. user has at least one quizz (draft, in evaluation, rejected, accepted)

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** Creator can see their Quizzes

- **MAIN SUCESS SCENARIO:** 
1. User enters '/' page
2. System shows page with 'My Quizzes' containing ALL their Quizzes

- **EXTENSIONS/ALTERNATIVE PATHS:** None

---

# Guidelines & Restrictions

- Show Quizz' question and state
- Color change depending on Quizz' state

