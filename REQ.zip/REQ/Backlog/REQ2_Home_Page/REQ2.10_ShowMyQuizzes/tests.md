# Test Report - REQ2.10 -  "Show My Quizzes "

## Test Scenery 
1. User is logged on
2. user has at least one quizz (draft, in evaluation, rejected, accepted)

## Actions
1. log in with 3 different users
2. check if the creators can see their quizzes

## Expected Result
1. User enters '/' page
2. System shows page with 'My Quizzes' containing ALL their Quizzes

## Result Obtained
**OK**