# Test Report - REQ2.4

## Test Scenery

1. User must be logged in

## Actions

1. Login to gain access to '/' view
2. Navigate to the other routes and use it's functionalities
   - profile
   - create-test
   - review-question
   - create-question
   - admin

## Expected Result

1. NavBar style and components remain the same despite changing route or using one's functionalities

## Result Obtained

**OK**

- Problem: Since the NavBar is a persistent and static style component it shouldn't have any transitions or style changing, but when we navigate throughout the app routes, the routes containing components take a sort of slide effect in and out of position.
- Report: All seems fixed.
- Conclusion: It's OK.
