# Test Report - REQ2.11 -  Navigate to 'Login' page -> LOGOUT

## Introduction
This report summarizes the testing performed to verify the logout functionality as per Requirement 2.11. The objective was to ensure that logging out from all sub-menu options correctly redirects users to the login page.

## Test Procedure
1. Logged in to the main pages.
2. Checked for the presence of the logout button.
3. Verified the functionality of the logout button in all sub-menu options.
4. Repeated steps 1-3 for each sub-menu option.
5. Logged back in after testing each sub-menu option.
6. Continued testing until all sub-menus and pages were confirmed to track back and redirect correctly to the login page after logout.

## Test Results
The logout functionality was successfully tested on all sub-menu options and pages. In each case, the logout button was present and functional, redirecting the user to the login page upon logging out.

## Conclusion
The logout functionality in compliance with Requirement 2.11 has been verified and found to be working as expected. All sub-menus and pages correctly redirect to the login page after the logout action.

This concludes the testing report for Requirement 2.11.

## Result Obtained
**OK**
