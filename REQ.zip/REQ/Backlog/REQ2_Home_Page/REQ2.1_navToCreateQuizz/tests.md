# Test Report - REQ2.1

## Test Scenery

1. Access, from all pages except from the Login Page, to the 'Create Quiz' page through the 'Create Quiz' button on the navigation bar

## Actions

1. From the Landing Page use the 'Create Quiz' button, on the navbar, to go to the '/create-quiz' page
2. From the Admin Page use the 'Create Quiz' button, on the navbar, to go to the '/create-quiz' page
3. From the Review Quiz Page use the 'Create Quiz' button, on the navbar, to go to the '/create-quiz' page
4. From the Create Test Page use the 'Create Quiz' button, on the navbar, to go to the '/create-quiz' page
5. From the Profile Page use the 'Create Quiz' button, on the navbar, to go to the '/create-quiz' page

## Expected Result

1. From the Landing Page using the 'Create Quiz' button, on the navbar, goes to the '/create-quiz' page
2. From the Admin Page using the 'Create Quiz' button, on the navbar, goes to the '/create-quiz' page
3. From the Review Quiz Page using the 'Create Quiz' button, on the navbar, goes to the '/create-quiz' page
4. From the Create Test Page using the 'Create Quiz' button, on the navbar, goes to the '/create-quiz' page
5. From the Profile Page using the 'Create Quiz' button, on the navbar, goes to the '/create-quiz' page

## Result Obtained
**OK**
