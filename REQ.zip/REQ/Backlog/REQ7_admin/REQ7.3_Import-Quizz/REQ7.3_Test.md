# Test Report - REQ7.3

- **Test Scenery:** 
1. Admin is logged on
2. Admin is in the '/admin' page

- **Actions:** 
1. Admin log's in at 'http://localhost:3000'
2. Aftwards, admin goes to '/admin' page
3. Then, admin selects the Choose File button
4. Admin chooses a 'XML' file and tries to import it, pressing the "IMPORT" button

- **Expeted Result:**
1. After pressing the 'IMPORT' button, appears the following text: "Quizzes read successfully!" if the file is accepted (XML)

- **Result Obtained:** NOT OK
1. The Admin receives an 'Error reading quizzes!' error when trying to import the XML File