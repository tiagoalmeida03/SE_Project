# Test Report - REQ{7.2}

## Test Scenery

1. Admin is logged on
2. At least one Quizz to export 

## Actions

1. List all the actions that admin can do
2. Test export and import bottons

## Expected Result

1. Admin page appears
2. Import and export work

## Result Obtained
**{OK}**

