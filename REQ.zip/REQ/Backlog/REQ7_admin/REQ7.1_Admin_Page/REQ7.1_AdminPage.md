# REQ7.1 - '/admin' page

- **PRIMARY ACTOR:** Admin

- **SCOPE:** User Goals

- **STAKEHOLDER AND INTERESTS:** None

- **PRECONDITIONS:**
1. Admin is logged on

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** Admin enter '/admin' page

- **MAIN SUCESS SCENARIO:** 
1. Admin enters '/admin' page
2. System shows '/admin' page with Import and Export Quizzes options

- **EXTENSIONS/ALTERNATIVE PATHS:** None

---

# Guidelines & Restrictions

- Every User is Admin
