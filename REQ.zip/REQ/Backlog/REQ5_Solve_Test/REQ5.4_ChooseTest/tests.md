# Test Report - REQ5.4 - Choose Test

## Test Procedure

1. User enters '/choose-test' page
2. Solver selects 1 test

- EXTENSIONS/ALTERNATIVE PATHS:

---

## Test Results

1. Solver is able to be redirected to the '/choose-test' page
2. Although the system shows the tests' names, it doesnt show which tags exactly each test has
3. Solver can select any test available
4. Solver is able to be redirected to the '/solve-test/{test_id}' page

## Conclusion

Every test has been concluded successfully. However, it displays ALL tags and not the tags of the given test.

This concludes the testing report for Requirement 5.4

---

*Tester: Joao Ribeiro*
*Date: 15/10/2023*
