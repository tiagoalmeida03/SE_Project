## testes

- Criei 2 testes para o solver ter como opção.
SUCESS GUARANTEE:
	- O user consegue ver os 2 testes disponíveis.

- Ao clicar no teste o user pode responder ao teste, depois de dar submit ele torna-se num solver.
- Quando o teste fica resolvido desaparece da tab do solve test e a informação das perguntas certas e erradas fica num gráfico na tab do user.

MAIN SUCESS SCENARIO:
	- Se o user entra http://localhost:3000/solve-test/{test_id} ele entra na página do teste (com todas as perguntas e botões de submit e cancel) e pode tentar fazê-lo outra vez mas se der submit reparei que fica apenas uma tela branca,e acho que não conta como um teste resolvido.

- Este Requerimento foi um sucesso.