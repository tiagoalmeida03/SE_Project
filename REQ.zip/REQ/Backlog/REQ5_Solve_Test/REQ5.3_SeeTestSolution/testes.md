## Testes

- Criei 2 testes

## Primeiro teste
    - User introduz '/solve-test/{tes_id}'
    - User é redirecionado para a página do teste
    - Quando resolvido, a grade do teste aparece corretamente

## Segundo teste
    - User introduz '/solve-test/{tes_id}'
    - User é redirecionado para a página do teste
    - User clica no botão 'Cancel'
    - User é redirecionado para a página principal como esperado

## Conclusão
- O requerimento foi um sucesso
    