## Test Report - REQ5.5

## Test Scenario
- The user enters the page "/choose-test
- The system shows the page with the tests (it shows the TAGS and the title of each test)

## Expected result
- Visualization of the created test (title and tags)

## Test 1
- A test was created by entering the '/create-test' page
- The test and its tags were then displayed by entering the '/choose-test' page, if this test is not solved

## Test 2
- A test was created by going to the '/create-test' page
- The test and its tags were then displayed by entering the '/choose-test' page, if this test is not solved

## Comments
- You can only view created tests, not solved ones. When they are resolved, they disappear from the test list
- Tests are ordered in ascending order of creation, so each test created is created with the number after the last test created

## Result Obtained
**OK**

- Problem: Second test couldn´t be viewed.
- Report: All seems fixed.
- Conclusion: It's OK.