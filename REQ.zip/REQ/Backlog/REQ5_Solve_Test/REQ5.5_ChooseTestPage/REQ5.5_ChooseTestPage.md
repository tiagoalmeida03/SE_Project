# REQ5.5 - Choose Test page

- **PRIMARY ACTOR:** Solver

- **SCOPE:** User Goals

- **STAKEHOLDER AND INTERESTS:** Solvers

- **PRECONDITIONS:**
1. Solver is logged on
2. Solver has at least one test available

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** Solver can see all tests available (not solved by him yet) to solve

- **MAIN SUCESS SCENARIO:** 
1. User enters '/choose-test' page
2. System shows page with Tests (show TAGS and Title of the every test)

- **EXTENSIONS/ALTERNATIVE PATHS:** None


---

# Guidelines & Restrictions

None