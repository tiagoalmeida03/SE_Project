# USER STORY - SOLVE TEST

As a Solver, I want to be able to solve tests in order to practice my Software Engineering knowledge.