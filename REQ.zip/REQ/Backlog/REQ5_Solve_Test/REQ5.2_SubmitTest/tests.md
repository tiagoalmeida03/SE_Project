# Test Report - REQ5.2

## Test Scenery

1. Solver is logged on
2. Solver has at least one test available

## Actions

1. User chooses a test
2. User selects options
3. User clicks 'Submit'

- EXTENSIONS/ALTERNATIVE PATHS:

2. User clicks 'Cancel'

## Expected Result

1. System feedback: 'Test Completed' (and solved_test is stored)

- EXTENSIONS/ALTERNATIVE PATHS:

1. System redirects to '/home' page

## Result Obtained
**OK**

- Problem: 'Test Completed' message not being diplayed after submiting test.
- Report: All seems fixed.
- Conclusion: It's OK.
