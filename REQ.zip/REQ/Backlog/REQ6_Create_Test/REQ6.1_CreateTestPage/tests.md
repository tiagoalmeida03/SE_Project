# Test Report - REQ6.1

## Test Scenery

1. Solver is logged in
2. At least 20 questions are available

## Actions

1. Click on 'Create Test' in the navbar
2. Write a title
3. Select 4 tags
4. Click on 'Create'

## Expected Result

1. Solver is redirected to the home page
2. A new test is created

## Result Obtained
**OK**
