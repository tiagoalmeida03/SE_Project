# REQ6.1 - Test Creation: '/create-test' page

- **PRIMARY ACTOR:** Creator

- **SCOPE:** User Goals

- **STAKEHOLDER AND INTERESTS:** Creators, Solvers

- **PRECONDITIONS:**
1. Creator is logged on

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** Creator can see '/create-test' page

- **MAIN SUCESS SCENARIO:**
1. Creator enters '/create-test' page
2. System shows page with Title box , all 12 tags, Submit and Cancel options

- **EXTENSIONS/ALTERNATIVE PATHS:** None

---

# Guidelines & Restrictions

- User can only select 2 TAGS