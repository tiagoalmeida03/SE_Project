# Test Report - REQ6.3

## Test Scenery

1. Creator is logged in

## Actions

1. Click on 'Create Test' in the navbar
2. Click on 'Cancel'

## Expected Result

1. Creator is redirected to the create test page
2. Creator can see all the existing tags
3. Creator is redirected to the home page

## Result Obtained
**OK**
1. The Creator can sucessfuly see all the Tags