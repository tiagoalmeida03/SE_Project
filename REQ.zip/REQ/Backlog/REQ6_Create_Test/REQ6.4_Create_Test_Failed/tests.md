# Test Report - REQ6.4

## Test Scenery

1. The Creator is logged into the system.

## Actions Taken

1. The Creator clicks on 'Create Test.'
2. A title is entered.
3. Two tags are selected.
4. The 'Create' button is pressed.

## Expected Outcome

1. The system should provide feedback indicating "Creation failed".

## Result Obtained

**OK**

- Problem: Error messages in test creation where not working (needed title and at least 2 tags).
- Report: Everything is working correctly.
- Conclusion: It's OK