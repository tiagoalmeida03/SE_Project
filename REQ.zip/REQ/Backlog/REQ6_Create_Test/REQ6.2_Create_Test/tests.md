# Test Report - REQ6.2

## Test Scenery

1. Solver is logged in
2. At least 20 questions are available

## Actions

1. Click on 'Create Test' in the navbar
2. Select 2 tags
3. Write a title
4. Click on 'Create'

## Expected Result

1. Solver is redirected to the home page
2. A new test is created
3. The test is connected with the selected tags

## Result Obtained
**OK**

- Problem: Test has all the tags despite not all being selected when creating it.
- Report: All seems fixed.
- Conclusion: It's OK.
