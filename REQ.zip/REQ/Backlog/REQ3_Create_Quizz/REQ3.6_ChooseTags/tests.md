# Test Report - REQ{3.6}

## Test Scenery

1. Creator is logged on

## Actions

1. Entered '/create-quizz' page
2. Choose one or more predefined TAG(s)

## Expected Result

1. It's possible to choose one or more predefined TAG(s)

## Result Obtained
**NOT OK**

The user can choose just one TAG.
