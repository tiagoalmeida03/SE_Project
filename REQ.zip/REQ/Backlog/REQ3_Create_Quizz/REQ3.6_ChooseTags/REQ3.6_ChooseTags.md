# REQ3.6 - Choose one or more predefined TAG(s)

- **PRIMARY ACTOR:** Creator

- **SCOPE:**  User Goals

- **STAKEHOLDER AND INTERESTS:** Reviewers, Solvers

- **PRECONDITIONS:**
1. Creator is logged on

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:**  Creator can choose one or more predefined TAG(s) to their quizzes (when creating)

- **MAIN SUCESS SCENARIO:**
1. User enters '/create-quizz' page
2. Creator choose one or more predefined TAG(s) to their quizzes(when creating)

- **EXTENSIONS/ALTERNATIVE PATHS:** None

---

# Guidelines & Restrictions

-  All boxes * :
1. 'What's your question?' box
2. 'Optional text' box
3. 6 'Option' boxes
4. 6 'Justification' boxes
5. 6 checkboxes
6. TAG select box

- CANCEL , SAVE and SUBMIT button
