# Test Report - REQ{3.5}

## Test Scenery

1. Creator is logged on

## Actions

1. Entered '/create-quizz' page
2. Filled up the boxes with information
3. Saved the quiz with filled boxes
3. Left '/create-quizz' page
4. Entered '/create-quizz' page 

## Expected Result

1. view the quiz creation page with draft information

## Result Obtained
**OK**

- Problem: The quiz did not have the boxes with Draft information previously filled .
- Report: You now can see the boxes with draft information filled.
- Conclusion: It's OK.
