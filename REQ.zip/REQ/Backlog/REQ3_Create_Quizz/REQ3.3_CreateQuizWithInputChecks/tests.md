# Test Report - REQ3.3

## Test Scenery

1. Creator is logged on

## Actions

1. Enter '/create-quizz' page
2. Fills all input boxes
3. Click 'CREATE' button

## Expected Result

1.Creator can create new Quiz

## Result Obtained
**OK**

The creator can create a Quiz and it will shows the page and the user fill all the input boxes and click on CREAT, and the System redirects to '/' page.