# Test Report - REQ3.7

## Test Scenery
- It is intended to evaluate if a question can be reject

## Actions

- 1-Click on "Create Question"
- 2-Choose a title
- 3-Choose at least two options from the available range
- 4-Select "SUBMIT"
- 5-Now it is necessary to switch account four times to either approve ou reject a new edit

## Expected Results

- While at least four accounts don't reject the question, it should remain "in evaluation"
- Later, when the sufficient number of users reject the question, it will change status to "rejected"


## Obtained results

**OK**
