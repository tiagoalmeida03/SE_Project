# Test Report - REQ{3.4}

## Test Scenery

1. Creator is logged on

## Actions

1. Enter '/create-quizz' page
2. Fills some input boxes (optional)
3. Click 'SAVE' button
4. Click 'CANCEL' button

## Expected Result

1. Creator can save a Quiz as a Draft

## Result Obtained
**OK**

- Problem: In the creation of a question it should be possible to save it as a draft without a TAG and without a selected option. Should not able to save without a title (if this happen the system should give feedback message "Please fill the title")
- Report: Problem is solved but the page to create quiz is no longer '/create-quizz' but its '/create-question'
- Conclusion: It's OK.
