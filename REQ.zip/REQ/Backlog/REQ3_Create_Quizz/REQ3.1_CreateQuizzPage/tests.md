# Test Report - REQ3.1 

## Test Scenery

1. User is logged on as "Creator"

## Test Procedure

Following the "Guidelines & Restrictions" section of "REQ3.1_CreateQuizzPage.md", the test went as it follows:

1. As logged on Creator, entered 'Create Quiz' page, with the url '/create-quizz'.
2. Confirmed the display of 'What's your question?' box
3. Confirmed the display of 'Optional text' box
4. Confirmed the display of the 6 'Option' boxes.
5. Confirmed the display of the 6 'Justification' boxes beneath the option boxes.
6. Confirmed the display of the 6 'Check' boxes next to the option boxes.
7. Confirmed the display of 'Select a tag' box at the top of the page.
8. Confirmed the display of "CANCEL" , "SAVE" and "SUBMIT" buttons at the bottom of the page.

## Expected Result

SUCESS GUARANTEE: Creator can visualize the quiz creation page
MAIN SUCESS SCENARIO: User enters '/create-quizz' page
and the system shows page with all boxes.

## Result Obtained
**OK**

Note: in the current state of the app, the current name of the page is 'Create Question', not 'Create Quiz'. 
