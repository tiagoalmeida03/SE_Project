# REQ3.1 - 'Create Quiz' page with all boxes to fill

- **PRIMARY ACTOR:** Creator

- **SCOPE:**  User Goals

- **STAKEHOLDER AND INTERESTS:** Reviewers, Solvers

- **PRECONDITIONS:**
1. Creator is logged on

- **MINIMAL GUARANTEE:** None

- **SUCESS GUARANTEE:** Creator can visualize the quiz creation page

- **MAIN SUCESS SCENARIO:**
1. User enters '/create-quizz' page
2. System shows page with all boxes *

- **EXTENSIONS/ALTERNATIVE PATHS:** None

---

# Guidelines & Restrictions

-  All boxes * : 
1. 'What's your question?' box
2. 'Optional text' box
3. 6 'Option' boxes
4. 6 'Justification' boxes
5. 6 checkboxes
6. TAG select box

- CANCEL , SAVE and SUBMIT button
