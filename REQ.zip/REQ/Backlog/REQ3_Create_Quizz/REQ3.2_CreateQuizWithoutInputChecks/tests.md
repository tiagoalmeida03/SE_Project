# Test Report - REQ3.2

## Test Scenery

1. Creator is logged on

## Actions

1. Enter '/create-quizz' page
3. Click 'CREATE' button

## Expected Result

1.Creator can´t create new Quiz without any input checks

## Result Obtained
**OK**

The creator enter the '/create-quizz' page and then clicks on "CREATE" bottom and the system give a message "Missing required fields" and stay in the same page. The creator can´t creat a new quiz without any input checks.