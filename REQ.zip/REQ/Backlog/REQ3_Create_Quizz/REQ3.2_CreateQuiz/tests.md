# Test Report - REQ3.2

## Test Scenery

1. Creator is logged on

## Actions

1. Enter '/create-quizz' page
3. Click 'CREATE' button

## Expected Result

1.Creator can´t create new Quiz without any input checks

## Result Obtained
**OK**

- Problem: The creator can creat a Quiz and it will shows the page and the user can fill some input boxes and submit, then the system give him a popup message "Quiz Submited" but the System doesn't redirects to '/' page.

- Report: All seems fixed.
- Conclusion: It's OK.
