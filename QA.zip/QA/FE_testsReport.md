## Test results

### REQ1 - Login

| Test | Result |
| :----: | :------: |
| [1.1_Login](/REQ/Backlog/REQ1_Login/REQ1.1_Login/REQ1.1_Login.md) | [OK](/REQ/Backlog/REQ1_Login/REQ1.1_Login/tests.md)|
| [1.2_Register](REQ/Backlog/REQ1_Login/REQ1.2_Register/REQ1.2_Register.md) | [OK](/REQ/Backlog/REQ1_Login/REQ1.2_Register/tests.md)|
| [1.3_Logout](/REQ/Backlog/REQ1_Login/REQ1.3_Logout/REQ1.3_Logout.md) | [OK](/REQ/Backlog/REQ1_Login/REQ1.3_Logout/tests.md) |

### REQ2 - Home Page

| Test | Result |
| :----: | :------: |
| [2.1_navToCreateQuiz](/REQ/Backlog/REQ2_Home_Page/REQ2.1_navToCreateQuizz/REQ2.1_navToCreateQuizz.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.1_navToCreateQuizz/tests.md) |
| [2.2_navToReviewQuiz](REQ/Backlog/REQ2_Home_Page/REQ2.2_navToReviewQuizz/REQ2.2_navToReviewQuizz.md) | [OK](REQ/Backlog/REQ2_Home_Page/REQ2.2_navToReviewQuizz/tests.md) |
| [2.3_navToChooseTest](/REQ/Backlog/REQ2_Home_Page/REQ2.3_navToChooseTest/REQ2.3_navToChooseTest.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.3_navToChooseTest/tests.md) |
| [2.4_navBar](/REQ/Backlog/REQ2_Home_Page/REQ2.4_navBar/REQ2.4_NavBar.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.4_navBar/tests.md) |
| [2.5_navToCreateQuiz3](REQ/Backlog/REQ2_Home_Page/REQ2.5_navToCreateQuizz3/REQ2.5_navToCreateQuizz3.md) | [OK](REQ/Backlog/REQ2_Home_Page/REQ2.5_navToCreateQuizz3/tests.md) |
| [2.7_HallOfFame-creators](/REQ/Backlog/REQ2_Home_Page/REQ2.7_HallOfFame-Creators/REQ2.7_HallOfFame-Creators.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.7_HallOfFame-Creators/tests.md)|
| [2.9_HallOfFame-solvers](/REQ/Backlog/REQ2_Home_Page/REQ2.9_HallOfFame-Solvers/REQ2.9_HallOfFame-Solvers.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.9_HallOfFame-Solvers/tests.md)|
| [2.10_ShowMyQuizzes](REQ/Backlog/REQ2_Home_Page/REQ2.10_ShowMyQuizzes/REQ2.10_ShowMyQuizzes.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.10_ShowMyQuizzes/tests.md) |
| [2.11_navToLogin](/REQ/Backlog/REQ2_Home_Page/REQ2.11_navToLogin/REQ2.11_navToLogin.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.11_navToLogin/tests.md) |
| [2.12_navToProfile](/REQ/Backlog/REQ2_Home_Page/REQ2.12_navToProfilePage/REQ2.12_navToProfilePage.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.12_navToProfilePage/tests.md) |
| [2.13_navToAdmin](/REQ/Backlog/REQ2_Home_Page/REQ2.13_navToAdmin/REQ2.13_navToAdmin.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.13_navToAdmin/tests.md) |
| [2.14_BackHome](/REQ/Backlog/REQ2_Home_Page/REQ2.14_BackHome/REQ2.14_BackHome.md) | [OK](/REQ/Backlog/REQ2_Home_Page/REQ2.14_BackHome/tests.md) |

### REQ3 - Create Quizz

| Test | Result |
| :----: | :------: |
| [3.1_CreateQuizPage](/REQ/Backlog/REQ3_Create_Quizz/REQ3.1_CreateQuizzPage/REQ3.1_CreateQuizzPage.md) | [OK](/REQ/Backlog/REQ3_Create_Quizz/REQ3.1_CreateQuizzPage/tests.md) |
| [3.2_CreateQuiz](/REQ/Backlog/REQ3_Create_Quizz/REQ3.2_CreateQuizWithoutInputChecks/REQ3.2_CreateQuizWithoutInputChecks.md) | [OK](/REQ/Backlog/REQ3_Create_Quizz/REQ3.2_CreateQuizWithoutInputChecks/tests.md) |
| [3.3_SaveQuiz](REQ/Backlog/REQ3_Create_Quizz/REQ3.3_CreateQuizWithInputChecks/REQ3.3_CreateQuizWithInputChecks.md) | [OK](REQ/Backlog/REQ3_Create_Quizz/REQ3.3_CreateQuizWithInputChecks/tests.md) |
| [3.4_SaveQuiz](/REQ/Backlog/REQ3_Create_Quizz/REQ3.4_SaveQuiz/REQ3.4_SaveQuiz.md) | [OK](/REQ/Backlog/REQ3_Create_Quizz/REQ3.4_SaveQuiz/tests.md) |
| [3.5_EditDraft](REQ/Backlog/REQ3_Create_Quizz/REQ3.5_EditDraft/REQ3.5_EditDraft.md) | [OK](REQ/Backlog/REQ3_Create_Quizz/REQ3.5_EditDraft/tests.md) |
| [3.6_EditDraft](REQ/Backlog/REQ3_Create_Quizz/REQ3.6_ChooseTags/REQ3.6_ChooseTags.md) | [OK](REQ/Backlog/REQ3_Create_Quizz/REQ3.6_ChooseTags/tests.md) |
| [3.7_EditRejected](/REQ/Backlog/REQ3_Create_Quizz/REQ3.7_EditRejected/REQ3.7_EditRejected.md) | [OK](/REQ/Backlog/REQ3_Create_Quizz/REQ3.7_EditRejected/tests.md) |


### REQ4 - Review Solve

| Test | Result |
| :----: | :------: |
| [4.1_VoteAcceptQuizz](/REQ/Backlog/REQ4_Review_Quizz/REQ4.1_VoteAcceptQuizz/REQ4.1_VoteAcceptQuizz.md) | [OK](/REQ/Backlog/REQ4_Review_Quizz/REQ4.1_VoteAcceptQuizz/tests.md) |
| [4.2_VoteRejectQuizz](/REQ/Backlog/REQ4_Review_Quizz/REQ4.2_VoteRejectQuizz/REQ4.2_VoteRejectQuizz.md) | [OK](/REQ/Backlog/REQ4_Review_Quizz/REQ4.2_VoteRejectQuizz/tests.md) |
| [4.3_QuizzReview](/REQ/Backlog/REQ4_Review_Quizz/REQ4.3_QuizzReview/REQ4.3_QuizzReview.md) | [OK](/REQ/Backlog/REQ4_Review_Quizz/REQ4.3_QuizzReview/tests.md) |
| [4.4_QuizzReviewPage](/REQ/Backlog/REQ4_Review_Quizz/REQ4.4_Review_Quizz_UserStory/REQ4_ReviewQuizz_UserStory.md) | [OK](/REQ/Backlog/REQ4_Review_Quizz/REQ4.4_Review_Quizz_UserStory/tests.md) |


| Test | Result |
| :----: | :------: |
| [5_SolveTest_UserStory](/REQ/Backlog/REQ5_Solve_Test/REQ5_Solve_Test_UserStory/REQ5_SolveTest_UserStory.md) | [OK](/REQ/Backlog/REQ5_Solve_Test/REQ5_Solve_Test_UserStory/tests.md) |
| [5.1_SolveTestPage](/REQ/Backlog/REQ5_Solve_Test/REQ5.1_SolveTest_UserStory/REQ5.1_SolveTestPage.md) | [OK](/REQ/Backlog/REQ5_Solve_Test/REQ5.1_SolveTest_UserStory/Tests.md) |
| [5.2_SubmitTest](REQ/Backlog/REQ5_Solve_Test/REQ5.2_SubmitTest/REQ5.2_SubmitTest.md) | [OK](REQ/Backlog/REQ5_Solve_Test/REQ5.2_SubmitTest/tests.md) |
| [5.3_SeeTestSolution](/REQ/Backlog/REQ5_Solve_Test/REQ5.3_SeeTestSolution/REQ5.3_SeeTestSolution.md) | [OK](/REQ/Backlog/REQ5_Solve_Test/REQ5.3_SeeTestSolution/testes.md) |
| [5.4_ChooseTest](/REQ/Backlog/REQ5_Solve_Test/REQ5.4_ChooseTest/REQ5.4_ChooseTest.md) | [OK](/REQ/Backlog/REQ5_Solve_Test/REQ5.4_ChooseTest/tests.md) |
| [5.5_ChooseTestPage](/REQ/Backlog/REQ5_Solve_Test/REQ5.5_ChooseTestPage/REQ5.5_ChooseTestPage.md) | [OK](/REQ/Backlog/REQ5_Solve_Test/REQ5.5_ChooseTestPage/tests.md) |


### REQ6 - Create Test

| Test | Result |
| :----: | :------: |
| [6.1_CreateTestPage](/REQ/Backlog/REQ6_Create_Test/REQ6.1_CreateTestPage/REQ6.1_CreateTestPage.md) | [OK](/REQ/Backlog/REQ6_Create_Test/REQ6.1_CreateTestPage/tests.md) |
<<<<<<< HEAD
| [6.2_Create_Test](/REQ/Backlog/REQ6_Create_Test/REQ6.2_Create_Test/REQ6.2_Create_Test.md) | [NOT OK](/REQ/Backlog/REQ6_Create_Test/REQ6.2_Create_Test/tests.md) |
| [6.3_Creator_ExistingTags](/REQ/Backlog/REQ6_Create_Test/REQ6.3_Creator_ExistingTags/REQ6.3_Creator_ExistingTags.md) | [OK](/REQ/Backlog/REQ6_Create_Test/REQ6.3_Creator_ExistingTags/tests.md) |
=======
| [6.2_Create_Test](/REQ/Backlog/REQ6_Create_Test/REQ6.2_Create_Test/REQ6.2_Create_Test.md) | [OK](/REQ/Backlog/REQ6_Create_Test/REQ6.2_Create_Test/tests.md) |
>>>>>>> 30738123b60f22b19c939f6630e0642ea861279a
| [6.4_Create_Test_Failed](/REQ/Backlog/REQ6_Create_Test/REQ6.4_Create_Test_Failed/REQ6.4_Create_Test_Failed.md) | [OK](/REQ/Backlog/REQ6_Create_Test/REQ6.4_Create_Test_Failed/tests.md) |

### REQ7 - Admin

| Test | Result |
| :----: | :------: |
| [7.1_AdminPage](/REQ/Backlog/REQ7_admin/REQ7.1_Admin_Page/REQ7.1_AdminPage.md) | [OK] |
| [7.2_Export_Quizz_XML](/REQ/Backlog/REQ7_admin/REQ7.2_Export_Quizz_XML/REQ7.2_Export_Quizz_XML.md) | [OK](REQ/Backlog/REQ7_admin/REQ7.2_Export_Quizz_XML/teste.md) |
| [7.3_Import-Quizz_XML](/REQ/Backlog/REQ7_admin/REQ7.3_Import-Quizz/REQ7.3_Import-Quizz_XML.md) | [NOT OK](/REQ/Backlog/REQ7_admin/REQ7.3_Import-Quizz/REQ7.3_Test.md) |

### REQ8 - Profile Page

| Test | Result |
| :----: | :------: |
| [8.2_ProfileDetails](/REQ/Backlog/REQ8_ProfilePage/REQ8.2_ProfileDetails/REQ8.2_ProfileDetails.md) | [OK](/REQ/Backlog/REQ8_ProfilePage/REQ8.2_ProfileDetails/REQ8.2_teste.md) |
| [8.3_PerformanceByTag](/REQ/Backlog/REQ8_ProfilePage/REQ8.3_PerformanceByTag/REQ8.3_PerformanceByTag.md) | [OK](/REQ/Backlog/REQ8_ProfilePage/REQ8.3_PerformanceByTag/tests.md) |

