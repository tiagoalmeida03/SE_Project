#QUALITY ASSURANCE

This folder is used to store all the files that are intended to guarantee the quality of the project 

| Folder | Description |
| :------: | :-----------: |
| [BE_testsReport](./BE_testsReport) | folder containing the backend tests |
| [cypress](./cypress) | folder containing the frontend auto_tests |
| [FE_testsReport](./FE_testsReport) | folder containing the results of the tests |
