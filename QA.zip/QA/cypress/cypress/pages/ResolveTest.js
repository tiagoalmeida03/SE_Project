class ResolveTestPage {
  elements = {
    optionBtn: (question, option) => cy.get(`#question-${question} > #options > #option-${option}`),
    submitBtn: () => cy.get('#submit'),
    cancelBtn: () => cy.get('#cancel'),
    grade: () => cy.get('#grade'),
    justification: (n) => cy.get(`##justification-${n}`),
  };

  clickOptionBtn(q, o) {
    this.elements.optionBtn(q, o).click();
  }

  clickSubmitBtn() {
    this.elements.submitBtn().click();
  }

  clickCancelBtn() {
    this.elements.cancelBtn().click();
  }

  checkQuestions() {
    for (let i = 0; i < 20; i++) {
      for (let j = 0; j < 6; j++) {
        this.elements.optionBtn(i, j).should('exist');
      }
    }
  }

  checkAnswers() {
    for (let i = 0; i < 20; i++) {
      this.elements.justification(i).should('exist');
    }
  }

  checkSubmitBtn() {
    this.elements.submitBtn().should('exist');
  }

  checkCancelBtn() {
    this.elements.cancelBtn().should('exist');
  }
}

export const resolveTestPage = new ResolveTestPage();
