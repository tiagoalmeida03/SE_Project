class ChooseTestPage {
  elements = {
    test: () => cy.get('#surveys > :nth-child(1)'),
  };

  clickTestBtn() {
    this.elements.test().click();
  }
}

export const chooseTestPage = new ChooseTestPage();
