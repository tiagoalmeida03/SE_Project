class LoginPage {
  elements = {
    usernameLoginInput: () => cy.get('#username-1'),
    passwordRegisterInput: () => cy.get('#password-1'),
    loginBtn: () => cy.get('#button-1'),
  };

  typeUsernameLogin(username) {
    this.elements.usernameLoginInput().type(username);
  }

  typePassword(password) {
    this.elements.passwordRegisterInput().type(password);
  }

  clickLogin() {
    this.elements.loginBtn().click();
  }

  submitLogin(username, password) {
    this.elements.usernameLoginInput().type(username);
    this.elements.passwordRegisterInput().type(password);
    this.elements.loginBtn().click();
  }
}

export const loginPage = new LoginPage();
