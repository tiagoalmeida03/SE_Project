class CreateTestPage {
  elements = {
    createBtn: () => cy.get('#create'),
    title: () => cy.get('#title'),
    tag: (n) => cy.get(`#tag-${n}`),
  };

  typeTitle(title) {
    this.elements.title().type(title);
  }

  selectTag(n) {
    this.elements.tag(n).click();
  }

  createTest() {
    this.elements.createBtn().click();
  }
}

export const createTestPage = new CreateTestPage();
