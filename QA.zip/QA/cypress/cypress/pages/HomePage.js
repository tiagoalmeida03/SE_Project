class HomePage {
  elements = {
    myQuestions: () => cy.get(':nth-child(1) > h2'),
    hallOfFame: () => cy.get(':nth-child(2) > h2'),
    creator: (n) => cy.get(`#creator-${n}`),
  };

  creatorScore(n) {
    return this.elements.creator(n).find('span:nth-child(2)');
  }
}

export const homePage = new HomePage();
