class ReviewQuestion {
  elements = {
    acceptBtn: () => cy.get('#Accept'),
    rejectBtn: () => cy.get('#Reject'),
    submitBtn: () => cy.get('#submit-question'),
  }

  clickAcceptBtn() {
    this.elements.acceptBtn().click();
  }

  clickRejectBtn() {
    this.elements.rejectBtn().click();
  }

  clickSubmitBtn() {
    this.elements.submitBtn().click();
  }
}

export const reviewQuestion = new ReviewQuestion();