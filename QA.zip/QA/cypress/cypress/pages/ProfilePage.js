class ProfilePage {
  elements = {
    quizzesChart: () => cy.contains('QUIZZES'),
    answersChart: () => cy.contains('ANSWERS')
  };
}

export const profilePage = new ProfilePage();
