class CreateQuestionPage {
  elements = {
    tag: () => cy.get('select'),
    question: () => cy.get('#question'),
    description: () => cy.get('#description'),
    options: (n) => cy.get(`#option-${n}`),
    justification: (n) => cy.get(`#justification-${n}`),
    checkbox: (n) => cy.get(`#checkbox-${n}`),
    cancel: () => cy.get('#cancel'),
    save: () => cy.get('#save'),
    submit: () => cy.get('#submit'),
  };

  selectTag() {
    this.elements.tag().select(1); // select the first tag
  }

  clickSaveBtn() {
    this.elements.save().click();
  }

  clickSubmitButton() {
    this.elements.submit().click();
  }

  clickCancelButton() {
    this.elements.cancel().click();
  }

  fillElements() {
    this.elements.tag().select("PM")

    this.elements.question().type("Qual a cor do ceu?")
    this.elements.description().type('olha para cima')

    this.elements.options(1).type('verde')
    this.elements.justification(1).type('porque sim')
    this.elements.options(2).type('amarelo')
    this.elements.justification(2).type('porque sim')
    this.elements.options(3).type('roxo')
    this.elements.justification(3).type('porque sim')
    this.elements.options(4).type('lilas')
    this.elements.justification(4).type('porque sim')
    this.elements.options(5).type('branco')
    this.elements.justification(5).type('porque sim')
    this.elements.options(0).type('preto')
    this.elements.justification(0).type('porque sim')
    this.elements.checkbox(1).click()

    cy.intercept("POST","http://localhost:8080/api/save-quiz").as("saveQuestion");
    this.elements.save().click()
    cy.wait("@saveQuestion");

  }
}

export const createQuestionPage = new CreateQuestionPage();