class NavBar {
  elements = {
    logo: () => cy.get('#logo'),
    solveTestBtn: () => cy.get('[href="/choose-test"]'),
    createQuestionBtn: () => cy.get('[href="/create-question"]'),
    reviewQuestionBtn: () => cy.get('[href="/review-question"]'),
    createTestBtn: () => cy.get('[href="/create-test"]'),
    logoutBtn: () => cy.get('#logout'),
    adminBtn: () => cy.get('[href="/admin"]'),
    profileBtn: () => cy.get('[href="/profile"]'),
  };

  clickHomeBtn() {
    this.elements.logo().click();
  }

  clickSolveTestBtn() {
    this.elements.solveTestBtn().click();
  }

  clickCreateQuestionBtn() {
    this.elements.createQuestionBtn().click();
  }

  clickCreateTestBtn() {
    this.elements.createTestBtn().click();
  }

  clickLogoutBtn() {
    this.elements.logoutBtn().click();
  }

  clickAdminBtn() {
    this.elements.adminBtn().click();
  }

  clickProfileBtn() {
    this.elements.profileBtn().click();
  }

  clickReviewQuestionBtn() {
    this.elements.reviewQuestionBtn().click();
  }
}

export const navBar = new NavBar();
