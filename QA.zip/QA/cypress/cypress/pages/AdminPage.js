class AdminPage {
  elements = {
    exportBtn: () => cy.get('#export'),
    importBtn: () => cy.get('#import'),
    importInput: () => cy.get('#importInput'),
  };

  clickExportBtn() {
    this.elements.exportBtn().click();
  }

  clickImportBtn() {
    this.elements.importBtn().click();
  }
}

export const adminPage = new AdminPage();
