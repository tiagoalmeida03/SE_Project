class RegisterPage {
  elements = {
    usernameRegisterInput: () => cy.get('#username-2'),
    passwordRegisterInput: () => cy.get('#password-2'),
    registerBtn: () => cy.get('#button-2'),
  };

  typeUsername(username) {
    this.elements.usernameRegisterInput().type(username);
  }

  typePassword(password) {
    this.elements.passwordRegisterInput().type(password);
  }

  clickRegister() {
    this.elements.registerBtn().click();
  }

  submitRegister(username, password) {
    this.elements.usernameRegisterInput().type(username);
    this.elements.passwordRegisterInput().type(password);
    this.elements.registerBtn().click();
  }
}

export const registerPage = new RegisterPage();
