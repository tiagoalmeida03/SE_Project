import { Then } from "@badeball/cypress-cucumber-preprocessor";

import { homePage } from "../../pages/HomePage";

Then("The user should be able to see his questions", () => {
  homePage.elements.myQuestions().should("be.visible");
});

Then("The user should be able to see the hall of fame", () => {
  homePage.elements.hallOfFame().should("be.visible");
});

Then('Each solver has a name and score', () => {
  cy.get('._solvers_1nsyy_53 span:nth-child(1)').should('have.length.greaterThan', 0);
  cy.get('._solvers_1nsyy_53 span:nth-child(2)').should('have.length.greaterThan', 0);
});

Then('The Hall should have the solvers sorted by score', () => {
  cy.get('._solvers_1nsyy_53 span:nth-child(2)').then($scores => {
    for (let i = 1; i < $scores.length; i++) {
      const currentScore = parseInt($scores[i].textContent, 10);
      const previousScore = parseInt($scores[i - 1].textContent, 10);
      expect(currentScore).to.be.lessThan(previousScore);
    }
  });
});

Then('The user should see the creators list sorted by score', () => {
  // first should be greater than second creatorScore(1) > creatorScore(2)
  homePage.creatorScore(1).then($score1 => {
    homePage.creatorScore(2).then($score2 => {
      const score1 = parseInt($score1.text(), 10);
      const score2 = parseInt($score2.text(), 10);
      expect(score1).to.be.greaterThan(score2);
    });
  });
});

Then("The user should see his recently created quiz", () => {
  cy.contains("Pergunta: Testing").should('exist');
});

Then("The user's recently created quiz's status should be rejected", () => {
  cy.contains("Pergunta: Testing").get("_state4_1nsyy_153").check('rejected');
});