import { Then } from '@badeball/cypress-cucumber-preprocessor';

import { navBar } from '../../pages/NavBar'

Then('The user navigates to the create test page', () => {
  navBar.clickCreateTestBtn()
})

Then('The user navigates to the create question page', () => {
  navBar.clickCreateQuestionBtn();
})

Then('The user navigates to the solve test page', () => {
  navBar.clickSolveTestBtn()
})

Then('The user navigates to the review question page', () => {
  navBar.clickReviewQuestionBtn();
})

Then('The user navigates to the admin page', () => {
  navBar.clickAdminBtn()
})

Then('The user should be on admin page', () => {
  cy.url().should('include', '/admin')
})

Then('The user navigates to the review quiz page', () => {
  navBar.clickReviewQuizBtn();
})
