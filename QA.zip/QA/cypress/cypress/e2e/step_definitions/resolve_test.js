import { Then } from '@badeball/cypress-cucumber-preprocessor';

import { resolveTestPage } from '../../pages/ResolveTest'

Then('The user chooses options', () => {
  for (let i = 0; i < 20; i++) {
    resolveTestPage.clickOptionBtn(i, Math.floor(Math.random() * 6));
  }
});

Then('The user clicks the submit button', () => {
  resolveTestPage.clickSubmitBtn()
});

Then('The user clicks the cancel button', () => {
  resolveTestPage.clickCancelBtn()
});

Then('The user should be able to see Test Completed message', () => {
  cy.on('window:alert', (text) => {
    expect(text).to.equal('Test Completed');
  });
});

Then('The user should be able to see all the questions on the solve test page', () => {
  resolveTestPage.checkQuestions();
});

Then('The user should be able to see the submit button', () => {
  cy.scrollTo('bottom');
  resolveTestPage.checkSubmitBtn();
});

Then('The user should be able to see the cancel button', () => {
  cy.scrollTo('bottom');
  resolveTestPage.checkCancelBtn();
});

Then('The user should be able to see all the answers', () => {
  resolveTestPage.checkAnswers();
});