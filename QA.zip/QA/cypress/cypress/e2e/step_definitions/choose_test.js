import { Then } from "@badeball/cypress-cucumber-preprocessor";

import { chooseTestPage } from "../../pages/ChooseTest";

Then('The user selects the first test', () => {
  chooseTestPage.clickTestBtn()
});
