import { Then } from "@badeball/cypress-cucumber-preprocessor";

import { createTestPage } from "../../pages/CreateTestPage";

Then("The user should enter the test title {string}", (title) => {
  createTestPage.typeTitle(title);
});

Then("The user should select {string} tags", (n) => {
  for (let i = 0; i < n; i++) createTestPage.selectTag(i);
});

Then("The user should click on the create button", () => {
  createTestPage.createTest();
});
