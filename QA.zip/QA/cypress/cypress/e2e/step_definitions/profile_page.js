import { Then } from "@badeball/cypress-cucumber-preprocessor";

import { profilePage } from '../../pages/ProfilePage';

Then("The user can view the number of quizzes and answers charts", () => {
  profilePage.elements.quizzesChart().should('be.visible');
  profilePage.elements.answersChart().should('be.visible');
});
