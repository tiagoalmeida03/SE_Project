import { Then } from '@badeball/cypress-cucumber-preprocessor';

import { adminPage } from '../../pages/AdminPage';

Then('The user should click on the Choose File button and selects file', () => {
  adminPage.elements.importInput().selectFile('filename.xml');
});

Then('The user should click on the import button', () => {
  adminPage.clickImportBtn();
});

Then('The user should click on the export button', () => {
  adminPage.clickExportBtn();
});

Then('The user should verify the downloaded file', () => {
  cy.readFile('cypress\\Downloads\\fileName.xml')
    .should('exist')
});