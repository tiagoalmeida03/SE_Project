import {
  When,
  Then,
} from '@badeball/cypress-cucumber-preprocessor';

import { registerPage } from '../../pages/RegisterPage'
import { faker } from '@faker-js/faker';

When("The user enters valid data", () => {

  cy.writeFile('cypress/fixtures/register.json', {
    username: faker.internet.userName(),
    password: faker.internet.password(),
  })
  cy.fixture('register').then((register) => {
    registerPage.typeUsername(register.username)
    registerPage.typePassword(register.password)
  })
})

Then("Clicks on the register button", () => {
  registerPage.clickRegister()
})

When("The user enters invalid data", () => {
  registerPage.typeUsername('ad')
  registerPage.typePassword('ad')
})

Then("The user should not be redirected to the home page", () => {
  cy.url().should("include", "/login")
});

When("The user enters a existing username", () => {
  cy.fixture('register').then((register) => {
    registerPage.typeUsername(register.username)
    registerPage.typePassword(register.password)
  })
})