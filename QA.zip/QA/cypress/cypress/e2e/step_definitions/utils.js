import { Then } from "@badeball/cypress-cucumber-preprocessor";

Then('The user visits the {string} page', (page) => {
  cy.visit(`/${page}`);
});

Then("The user should see the alert message {string}", (msg) => {
  cy.on('window:alert', txt => {
    expect(txt).to.contains(msg);
  });
});

Then('The user should be on the {string} page', (page) => {
  cy.url().should('include', `/${page}`);
});