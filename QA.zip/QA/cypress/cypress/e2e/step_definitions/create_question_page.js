import { Then } from "@badeball/cypress-cucumber-preprocessor";

import { createQuestionPage } from "../../pages/CreateQuestionPage"

Then("The user selects the first tag", () => {
  createQuestionPage.selectTag();
})

Then("The user fills the title and description boxes", () => {
  createQuestionPage.elements.question().type('Question Title');
  createQuestionPage.elements.description().type('Question Description');
})

Then("The user fills all the option input boxes", () => {
  for (let i = 0; i < 6; i++) {
    createQuestionPage.elements.options(i).type(`Option ${i}`);
    createQuestionPage.elements.justification(i).type(`Justification ${i}`);
  }
})

Then("The user checks the correct answer", () => {
  createQuestionPage.elements.checkbox(Math.floor(Math.random() * 6)).check();
})

Then("The user clicks on the save button", () => {
  createQuestionPage.clickSaveBtn();
});

Then("The user clicks on the submit button", () => {
  createQuestionPage.clickSubmitButton();
});

Then("The user clicks on the cancel button", () => {
  createQuestionPage.clickCancelButton();
});

Then("The user fils the quizz options", () => {
  createQuestionPage.fillElements();
});