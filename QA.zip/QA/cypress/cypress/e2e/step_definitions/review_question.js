import { Then } from "@badeball/cypress-cucumber-preprocessor";

import { reviewQuestion } from "../../pages/ReviewQuestion";

Then("The user clicks on the Reject button", () => {
  cy.scrollTo('bottom');
  reviewQuestion.clickRejectBtn();
});

Then("The user clicks on the Accept button", () => {
  cy.scrollTo('bottom');
  reviewQuestion.clickAcceptBtn();
});

Then("The user clicks on the Submit button", () => {
  cy.scrollTo('top');
  reviewQuestion.clickSubmitBtn();
});
