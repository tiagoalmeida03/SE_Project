import { Then } from "@badeball/cypress-cucumber-preprocessor";

Then("The User selects one Draft", () => {
  cy.get("#my-quizzes").children().get('span:contains("draft"):first').click();
});

