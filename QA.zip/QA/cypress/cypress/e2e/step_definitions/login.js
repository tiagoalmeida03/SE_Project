import {
  Given,
  When,
  Then
} from '@badeball/cypress-cucumber-preprocessor';

import { loginPage } from '../../pages/LoginPage'
import { navBar } from '../../pages/NavBar'

Given('A web browser at the login page', () => {
  cy.visit('/login');
});

When('The user enters the username {string}, the password {string}, and clicks on the login button', (username, password) => {
  loginPage.submitLogin(username, password)
});
